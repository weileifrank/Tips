#!/bin/bash
BUILD_PATH="./build/Debug"
rm -rf "$BUILD_PATH"
if [ ! -d "$BUILD_PATH" ];then
  mkdir -p "$BUILD_PATH"
fi
TARGETS="armeabi-v7a arm64-v8a"
for TARGET in ${TARGETS}
do
    mkdir -p ${BUILD_PATH}/${TARGET}
    cd ${BUILD_PATH}/${TARGET}
    cmake -DCMAKE_TOOLCHAIN_FILE="${ANDROID_NDK}/build/cmake/android.toolchain.cmake" \
    -DCMAKE_BUILD_TYPE=Debug \
    -DANDROID_ABI=${TARGET} ../../..
    make -j8
#    跳转到根目录
    cd ../../..
done











#------------------------------------单个可用start----------------------------------------
#BUILD_PATH="./build/Debug"
#rm -rf "$BUILD_PATH"
#if [ ! -d "$BUILD_PATH" ];then
#  mkdir -p "$BUILD_PATH"
#fi
#TARGETS="armeabi-v7a"
##TARGETS="arm64-v8a"
#for TARGET in ${TARGETS}
#do
#    mkdir -p ${BUILD_PATH}/${TARGET}
#    cd ${BUILD_PATH}/${TARGET}
#    cmake -DCMAKE_TOOLCHAIN_FILE="${ANDROID_NDK}/build/cmake/android.toolchain.cmake" \
#    -DCMAKE_BUILD_TYPE=Debug \
#    -DANDROID_ABI=${TARGET} ../../..
#    make -j8
#done
#------------------------------------单个可用end----------------------------------------



#cmake \
#-DCMAKE_TOOLCHAIN_FILE=android.cmake ..
#make



#TARGETS="armeabi-v7a armeabi x86 mips arm64-v8a mips64"

#for TARGET in ${TARGETS}
#do
#    # create one build dir per target architecture
#    mkdir -p ${BUILD_PATH}/${TARGET}
#    cd ${BUILD_PATH}/${TARGET}
#
#    cmake -DANDROID_NATIVE_API_LEVEL=${ANDROID_NATIVE_API_LEVEL} -DCMAKE_TOOLCHAIN_FILE=${ANDROID_TOOLCHAIN} -DANDROID_NDK=${ANDROID_NDK} -DCMAKE_BUILD_TYPE=${CMAKE_BUILD_TYPE} -DANDROID_ABI=${TARGET} -DPROJ_HOME=${PROJ_HOME} ../../src
#
#    make -j32
#
#    cd -
#done