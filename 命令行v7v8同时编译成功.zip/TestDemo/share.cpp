#include <iostream>
#include "jni.h"
#include <android/log.h>

using namespace std;
int iprint() {
    cout << "Hello, World!" << endl;
    return 0;
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_hiscene_cppsodemo_MainActivity_test(
        JNIEnv* env,
        jobject /* this */) {
    __android_log_print(ANDROID_LOG_ERROR,"test_tag","jni print");
    std::string str = "Hello from so";
    return env->NewStringUTF(str.c_str());
}
